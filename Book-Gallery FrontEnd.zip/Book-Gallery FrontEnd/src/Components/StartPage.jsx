import React, { useState } from "react";
import { Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { API_URL } from "../constants";

function StartPage() {
  const navigate = useNavigate();

  const [inputData, setInputData] = useState({ name: "", email: "" });

  const goToHome = async () => {
    try {
      // Make API call to check email availability or create user
      const response = await fetch(API_URL + '/api/user', {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: inputData.name,
          email: inputData.email,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      // Extract user data from response
      const userData = await response.json();

      // Store user data in session storage
      sessionStorage.setItem("user", JSON.stringify(userData.user));

      // Redirect to home page after successful response
      navigate("/Home");
    } catch (error) {
      console.error("Error:", error);
      // Handle error here (e.g., display error message to user)
    }
  };

  function changeHandle(e) {
    setInputData({ ...inputData, [e.target.name]: e.target.value });
  }

  return (
    <>
      <div className="App">
        <header className="App-header">
          <h1
            style={{
              fontSize: "50px",
              fontFamily:
                'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif',
              padding: "15px",
              textAlign: "center",
            }}
          >
            Welcome to
            <p style={{ fontFamily: "'Courier New', Courier, monospace" }}>
              Book Gallery
            </p>
          </h1>

          <Container
            style={{
              textAlign: "center",
              // , border: "1px white solid"
            }}
          >
            <div
              className="container"
              style={{
                marginTop: "80px",
                height: "300px",
                width: "50%",
                padding: "10px",
                color: "whitesmoke",
              }}
            >
              Enter your name to start
              <Container
                style={{
                  padding: "12%",
                }}
              >
                <input
                  type="text"
                  name="name"
                  value={inputData.name}
                  onChange={changeHandle}
                  placeholder="Enter your Good Name"
                  className="form-control"
                  style={{
                    width: "100%",
                  }}
                />
                <br />
                <input
                  type="text"
                  name="email"
                  value={inputData.email}
                  onChange={changeHandle}
                  placeholder="Enter your Email "
                  className="form-control"
                  style={{
                    width: "100%",
                  }}
                />
                <button
                  onClick={goToHome}
                  className="btn btn-success"
                  style={{
                    marginTop: "5%",
                    display: "block",
                    width: "100%",
                    boxShadow: "2px 2px 5px rgb(122, 117, 101)",
                  }}
                  disabled={!(inputData.email && inputData.name)}
                >
                  Enter to the gallery
                </button>
              </Container>
            </div>
          </Container>
        </header>
      </div>
    </>
  );
}
export default StartPage;
