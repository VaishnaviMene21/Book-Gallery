import {
  CircularProgress,
  Container,
  Grid,
  Rating,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Button, Image } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import Footer from "../Headers/Footer";
import Head from "../Headers/Header";
import { API_URL } from "../constants";

function ViewBook() {
  const navigate = useNavigate();
  const [book, setBook] = useState();

  const [loading, setLoading] = useState(true);
  const { id } = useParams();

  useEffect(() => {
    const fetchBookDetails = async () => {
      try {
        const response = await fetch(`${API_URL}/api/books/${id}`);
        if (!response.ok) {
          throw new Error("Failed to fetch book details");
        }
        const data = await response.json();
        console.log(data);
        setBook(data[0]);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching book details:", error);
        setLoading(false);
      }
    };

    fetchBookDetails();
  }, [id]);

  const goToReviewPage = (id) => {
    navigate("/ReviewBook/" + id);
  };

  const startpage = () => {
    navigate("/Home");
  };

  return (
    <>
      <Head />
      <div
        className="container"
        style={{ display: "flex", justifyContent: "center" }}
      >
        <Button
          onClick={startpage}
          className="btn btn-success"
          style={{
            display: "block",
            width: "80%",
            boxShadow: "2px 2px 5px rgb(122, 117, 101)",
          }}
        >
          Home
        </Button>
      </div>
      <hr />
      {loading ? (
        <CircularProgress size={30} />
      ) : (
        <div className="container" key={book.book_id}>
          <Container
            style={{
              backgroundColor: "whitesmoke",
              height: "30%",
              width: "100%",
              borderRadius: "10px",
              padding: "5%",
              boxShadow: "10px 10px 1px 1px rgba(100, 100, 100, 0.2)",
              margin: "3%",
            }}
          >
            <Grid container style={{ textAlign: "left" }}>
              <Grid xs={4} style={{ textAlign: "center", padding: "10px" }}>
                <hr style={{ width: "100%" }} />
                <Image
                  src={book.image}
                  alt={book.title}
                  fluid
                  rounded
                  style={{ height: "200px", width: "100px" }}
                />
                <hr style={{ width: "50%", marginLeft: "25%" }} />
                <Typography component="legend">Ratings</Typography>
                <Rating
                  name="read-only"
                  value={parseInt(book.rating)}
                  readOnly
                />
                <hr style={{ width: "100%" }} />
              </Grid>

              <Grid xs={8} style={{ padding: "10px" }}>
                <hr style={{ width: "100%" }} />
                <h2>{book.title}</h2>
                <p style={{ fontSize: "15px" }}> - {book.author}</p>
                <p className="container">{book.description}</p>
                <hr style={{ width: "100%" }} />
                <Button
                  onClick={() => goToReviewPage(book.book_id)}
                  style={{
                    display: "block",
                    marginLeft: "20%",
                    width: "50%",
                    boxShadow: "2px 2px 5px rgb(122, 117, 101)",
                  }}
                >
                  Write a Review
                </Button>
              </Grid>
            </Grid>
          </Container>
        </div>
      )}
      <Footer />
    </>
  );
}
export default ViewBook;
