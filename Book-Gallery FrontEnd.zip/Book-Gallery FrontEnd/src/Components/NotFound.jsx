// NotFound.js
import React from "react";

function NotFound() {
  return;
  <h2>404 Not Found</h2>;
}

export default NotFound;
