import React, { useEffect, useState } from "react";
import Card from "react-bootstrap/Card";
import { useNavigate } from "react-router-dom";
import { API_URL } from "../constants";
import { Tooltip } from "@mui/material";

function AllBooks() {
  const navigate = useNavigate();
  const goToBookDetailsPage = (id) => {
    navigate("/ViewBook/"+id);
  };
const [bookData,setBookData] = useState([])
  useEffect(() => {
    const fetchBooks = async () => {
        const response = await fetch(API_URL+'/api/books');
        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const data = await response.json();
        setBookData(data);
    };

    fetchBooks();
  }, []);

  return (
    <>
      <div
        className="container bgs"
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "20px",
        }}
      >
        {bookData.map((book) => (
        <Tooltip title='click to see more' >
          <Card
            key={book.book_id}
            style={{
              width: "20rem",
              boxShadow: "10px 10px 1px 1px rgba(100, 100, 100, 0.2)",
            }}
            onClick={() => {
              goToBookDetailsPage(book.book_id);
            }}
          >

            <Card.Img variant="top" src={book.image} />
            <hr />
            <Card.Body>
              <div style={{ textAlign: "left", marginBottom: ".10%" }}>
                <Card.Title>{book.title}</Card.Title>
                <Card.Text> - {book.author}</Card.Text>
              </div>
              {/* <Button variant="primary">Go somewhere</Button> */}
            </Card.Body>
          </Card>
          </Tooltip>

        ))}
      </div>
    </>
  );
}

export default AllBooks;
