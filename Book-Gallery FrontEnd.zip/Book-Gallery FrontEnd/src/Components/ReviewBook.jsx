import { Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

import {
  // Button,
  Container,
  Grid,
  Rating,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Footer from "../Headers/Footer";
import Head from "../Headers/Header";
import { API_URL } from "../constants";

function ReviewBook() {
  const [book, setBook] = useState({
    id: 1,
    image: "", // Add the book image URL
    title: "Title", // Add the book title
    author: "Author", // Add the book author
    rating: 0, // Initialize the ratings
  });
  const [value, setValue] = useState(0); // State for controlling the rating value
  const [comment, setComment] = useState(""); // State for comment text field
  const [review, setReview] = useState(""); // State for review text field
  const [user, setUser] = useState();
  useEffect(() => {
    // Retrieve user from session storage when component mounts
    const storedUser = sessionStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const { id } = useParams();

  useEffect(() => {
    const fetchBookDetails = async () => {
      try {
        const response = await fetch(`${API_URL}/api/books/${id}`);
        if (!response.ok) {
          throw new Error("Failed to fetch book details");
        }
        const data = await response.json();
        console.log(data);
        setBook(data[0]);
      } catch (error) {
        console.error("Error fetching book details:", error);
      }
    };

    fetchBookDetails();
  }, [id]);

  const handleSave = () => {
    const reviewData = {
      userId: user.id,
      bookId: book.book_id,
      comment: review,
      review: review,
      rating: value,
    };

    fetch(API_URL + "/api/reviews", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(reviewData),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to save review");
        }
        console.log("Review saved successfully");
        // Optionally, you can perform additional actions after saving the review
      })
      .catch((error) => {
        console.error("Error saving review:", error);
        // Handle errors here
      });
  };

  const navigate = useNavigate();

  const startpage = () => {
    navigate("/Home");
  };

  return (
    <>
      <Head />
      <div
        className="container"
        style={{ display: "flex", justifyContent: "center" }}
      >
        <Button
          onClick={startpage}
          className="btn btn-success"
          style={{
            display: "block",
            width: "80%",
            boxShadow: "2px 2px 5px rgb(122, 117, 101)",
          }}
        >
          Home
        </Button>
      </div>
      <hr />
      <div className="container">
        <Container
          style={{
            backgroundColor: "whitesmoke",
            height: "30%",
            width: "100%",
            borderRadius: "10px",
            boxShadow: "10px 10px 1px 1px rgba(100, 100, 100, 0.2)",
          }}
        >
          <div
            key={book.id}
            className="container"
            style={{
              padding: "3%",
              paddingTop: "1%",
              textAlign: "center",
            }}
          >
            <h3
              style={{
                marginTop: "2%",
                fontSize: "35px",
                fontWeight: "normal",
              }}
            >
              Review Book
            </h3>
            <Grid container style={{ marginTop: "2%", textAlign: "left" }}>
              <Grid
                xs={4}
                style={{
                  textAlign: "center",
                  padding: "5px",
                  alignItems: "center",
                }}
              >
                <hr style={{ width: "100%" }} />

                <hr style={{ width: "50%", marginLeft: "25%" }} />
                <h3>Title: {book.title}</h3>
                <p style={{ fontSize: "15px" }}>Author: {book.author}</p>
                <hr style={{ width: "100%" }} />
              </Grid>

              <Grid
                xs={8}
                style={{
                  padding: "5px",
                }}
              >
                <hr style={{ width: "100%" }} />
                <div className="container" style={{ paddingLeft: "5%" }}>
                  <TextField
                    id="standard-textarea"
                    label="Write your review."
                    placeholder="Write your review."
                    multiline
                    variant="standard"
                    rows={2}
                    style={{ width: "70%" }}
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                  />
                  <br />
                  <br />
                  <Typography component="legend">Rate this book:</Typography>
                  <Rating
                    name="simple-controlled"
                    value={value}
                    onChange={(event, newValue) => {
                      setValue(newValue);
                      setBook((prevBook) => ({
                        ...prevBook,
                        ratings: newValue,
                      }));
                    }}
                  />
                </div>
                <hr style={{ width: "100%" }} />
                <div style={{ paddingLeft: "20%" }}>
                  <Button
                    onClick={handleSave}
                    style={{
                      marginTop: "5%",
                      width: "60%",
                      backgroundColor: "#0288d1",
                      color: "white",
                    }}
                    type="button"
                  >
                    Save
                  </Button>
                </div>
              </Grid>
            </Grid>
          </div>
        </Container>
      </div>
      <Footer />
    </>
  );
}

export default ReviewBook;
