import React from "react";
import { useNavigate } from "react-router-dom";
import Footer from "../Headers/Footer";
import Header from "../Headers/Header";
import AllBooks from "./AllBooks";
import { Button } from "react-bootstrap";

function Home() {
  const navigate = useNavigate();

  const startpage = () => {
    navigate("/Home");
  };

  return (
    <>
      <Header />
      {/* <div
        className="container"
        style={{ display: "flex", justifyContent: "center" }}
      >
        <Button
          onClick={startpage}
          className="btn btn-success"
          style={{
            display: "block",
            width: "80%",
            boxShadow: "2px 2px 5px rgb(122, 117, 101)",
          }}
        >
          Home
        </Button>
      </div>
      <hr /> */}
      <AllBooks />
      <hr />
      <Footer />
    </>
  );
}

export default Home;
