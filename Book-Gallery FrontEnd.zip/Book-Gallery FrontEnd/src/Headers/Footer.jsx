import "./HeadStyle.css";
import React from "react";
function Footer() {
  return (
    <>
      <footer className="footerShadow">© Book Gallery | 2024</footer>
    </>
  );
}

export default Footer;
