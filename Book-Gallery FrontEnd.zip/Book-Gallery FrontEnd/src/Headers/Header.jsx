import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./HeadStyle.css";

function Head() {
  const navigate = useNavigate();
  const [user,setUser] = useState();
  useEffect(() => {
    // Retrieve user from session storage when component mounts
    const storedUser = sessionStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const goToHome = () => {
    navigate("./Home");
  };
  return (
    <>
      <div>
        <header className="headerShadow">
          <h1 onClick={goToHome}>Book Gallery</h1>
          <h3>
            Hello, {user && <h5>{user.username}</h5>}
            <h5> ;)</h5>

          </h3>
        </header>
      </div>
    </>
  );
}

export default Head;
